//
//  KZImage.h
//  KZImage
//
//  Created by 内山和也 on 2019/03/26.
//  Copyright (c) 2019年 内山和也. All rights reserved.
//

#import <Foundation/Foundation.h>
#include "ImageEnum.h"

@protocol KZImageDelegate <NSObject>
@optional
@end


@interface ConvertSetting : NSObject
@property KZColorSpace toSpace;
@property float Resolution;
@property BOOL isSaveLayer; // only use PSD writing
@property BOOL isResize;    // true: resample image     false : change dpi
@property BOOL isSaveColor; // true: save RGB image     false : save Gray image
@end

@interface KZImage : NSObject
- (void)startEngine;
- (void)stopEngine;

+ (BOOL)isSupported:(NSString*)imgPath;

- (NSData*)ImageConvertfromBuffer:(NSData*)img page:(NSUInteger)page format:(KZFileFormat)targetFormat setting:(ConvertSetting*)setting;
- (NSData*)ImageConvertfrom:(NSString*)imgPath page:(NSUInteger)page format:(KZFileFormat)targetFormat trimSize:(double)trimSize setting:(ConvertSetting*)setting;
- (NSString*)ImageConvertfromBuffer:(NSData*)img to:(NSString*)toFolder format:(KZFileFormat)targetFormat saveFileName:(NSString*)saveFileName setting:(ConvertSetting*)setting;
- (NSString*)ImageConvertfrom:(NSString*)imgPath page:(NSUInteger)page to:(NSString*)toFolder format:(KZFileFormat)targetFormat trimSize:(double)trimSize setting:(ConvertSetting*)setting;

- (BOOL)makePSDfromBufferTop:(NSData*)top low:(NSData*)low mid:(NSData*)mid savePath:(NSString*)savePath setting:(ConvertSetting*)setting;
- (BOOL)makePSDtop:(NSString*)top low:(NSString*)low mid:(NSString*)mid savePath:(NSString*)savePath setting:(ConvertSetting*)setting;
- (BOOL)makeGIFimgs:(NSArray*)imgs savePath:(NSString*)savePath;

- (NSSize)getPdfSize:(NSString*)imgPath;

@property (nonatomic) BOOL isModifyExtention; // Modify Extention Whwn Source Extention Difference RealFileFormat
@property (nonatomic) BOOL isDeleteLastFiles; // If Same File in Converted Path, Delete this file
@property (nonatomic, strong) id <KZImageDelegate> delegate;
@end
